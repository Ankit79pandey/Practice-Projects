package com.simplilearn.testing;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstScripts{
	
	
  public static void main(String[] args) {
	
	  
	  String path="D:\\Selenium\\chromedriver_win32 (2)\\chromedriver.exe";
	  
	  System.setProperty("webdriver.chrome.driver", path);
	  
	  WebDriver driver=new ChromeDriver();
	  
	  String url="http://www.google.com";
	  driver.get(url);
	  System.out.println("Title: "+driver.getTitle());
	  
	  System.out.println(driver.getCurrentUrl());
	  
	  assertEquals("Google",driver.getTitle());
	  
driver.close();
	  
}
}