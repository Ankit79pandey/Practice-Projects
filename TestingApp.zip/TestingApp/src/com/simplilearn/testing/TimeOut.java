package com.simplilearn.testing;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TimeOut {
	public static void main(String[] args) {
  String path="D:\\Selenium\\chromedriver_win32 (2)\\chromedriver.exe";
		  
		  System.setProperty("webdriver.chrome.driver", path);
		  
		  WebDriver driver=new ChromeDriver();
		  
		  driver.manage().window().maximize();
		  
		  
		  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		  
		  driver.manage().timeouts().setScriptTimeout(10, TimeUnit.SECONDS);
		  
		  driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		  
	
		  String url="https://www.facebook.com/";
		  driver.get(url);
		  
	  WebDriverWait explicitWait=new WebDriverWait(driver, 10);
		  
		  explicitWait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("email")));
		  WebElement email=driver.findElement(By.id("email"));
		  email.sendKeys("9911027949");
		  
	}

}
