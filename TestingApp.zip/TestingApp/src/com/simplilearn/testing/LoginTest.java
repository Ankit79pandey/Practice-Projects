package com.simplilearn.testing;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTest {
	
	public static void main(String[] args) {
		  String path="D:\\Selenium\\chromedriver_win32 (2)\\chromedriver.exe";
		  
		  System.setProperty("webdriver.chrome.driver", path);
		  
		  WebDriver driver=new ChromeDriver();
		  
		  String url="https://www.facebook.com/";
		  driver.get(url);
		  
		  driver.manage().window().maximize();
		  
		  WebElement email=driver.findElement(By.id("email"));
		  email.sendKeys("9911027949");
		  
		  WebElement Email_xpath=driver.findElement(By.xpath("//*[@id=\"email\"]"));
		  System.out.println("Email equals :"+email.equals(Email_xpath));
		  
		  WebElement Email_cssSelector=driver.findElement(By.cssSelector("#email"));
		  System.out.println("Email equals using selector is :"+Email_cssSelector.equals(Email_xpath));
		  
		  
		  
		  WebElement password=driver.findElement(By.id("pass"));
		  password.sendKeys("K1@khushi");
		  
		  
		  WebElement button=driver.findElement(By.name("login"));
		  button.submit();
		  
		

		  
	}

}
