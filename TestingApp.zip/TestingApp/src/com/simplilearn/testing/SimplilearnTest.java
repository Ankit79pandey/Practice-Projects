package com.simplilearn.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SimplilearnTest {

	
	public static void main(String[] args) {
		
  String path="D:\\Selenium\\chromedriver_win32 (2)\\chromedriver.exe";
		  
		  System.setProperty("webdriver.chrome.driver", path);
		  
		  WebDriver driver=new ChromeDriver();
		  
		  String url="https://accounts.simplilearn.com/user/login?redirect_url=https%3A%2F%2Flms.simplilearn.com%2F";
		  driver.get(url);
		  
		  driver.manage().window().maximize();
		  
		  WebElement email=driver.findElement(By.name("user_login"));
		  email.sendKeys("ankit.pandey3@mphasis.com");
		  
		  WebElement password=driver.findElement(By.name("user_pwd"));
		  password.sendKeys("Ankit@1998");
		  
		  
		  WebElement button=driver.findElement(By.name("btn_login"));
		  button.submit();
	}
}
