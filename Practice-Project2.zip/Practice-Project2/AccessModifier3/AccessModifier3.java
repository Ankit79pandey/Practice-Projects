package AccessModifier3;
import AssistedProjects.AccessModifiers1;
public class AccessModifier3 extends AccessModifiers1{
	
public static void main(String args[]) {
	    AccessModifier3 obj=new AccessModifier3();
	    obj.PublicMethod();
		//obj.PrivateMethod();
		//obj.defaultMethod();
		obj.ProtectedMethod();
	}
	}


