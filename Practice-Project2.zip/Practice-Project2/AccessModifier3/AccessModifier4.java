package AccessModifier3;
import AssistedProjects.AccessModifiers1;
public class AccessModifier4 {
	
public static void main(String args[]) {
	    AccessModifiers1 obj=new AccessModifiers1();
	    obj.PublicMethod();
		//obj.PrivateMethod();
		//obj.defaultMethod();
		//obj.ProtectedMethod();
	}
	}